/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package workout;

import java.util.Scanner;

// Abstract class Workout
abstract class Workout {
    protected String exercises;
    protected int duration;
    protected int intensityLevel;

    // Constructor for Workout
    public Workout(String exercises, int duration, int intensityLevel) {
        this.exercises = exercises;
        this.duration = duration;
        this.intensityLevel = intensityLevel;
    }

    // Get method for exercises
    public String getExercises() {
        return exercises;
    }

    // Get method for duration
    public int getDuration() {
        return duration;
    }

    // Get method for intensity level
    public int getIntensityLevel() {
        return intensityLevel;
    }
}

// Interface IWorkout
interface IWorkout {
    void printWorkout();
}

// Class ProcessWorkout that extends Workout and implements IWorkout
class ProcessWorkout extends Workout implements IWorkout {

    // Constructor for ProcessWorkout
    public ProcessWorkout(String exercises, int duration, int intensityLevel) {
        super(exercises, duration, intensityLevel); // Initialize superclass fields
    }

    // Override the printWorkout method
    @Override
    public void printWorkout() {
        System.out.println("Workout Details:");
        System.out.println("Exercises: " + getExercises());
        System.out.println("Duration: " + getDuration() + " minutes");
        System.out.println("Intensity Level: " + getIntensityLevel());
    }
}

// Main class WorkoutApplication
public class WorkoutApplication {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompting the user for workout details
        System.out.println("Enter the exercises (comma separated): ");
        String exercises = scanner.nextLine();

        System.out.println("Enter the duration (in minutes): ");
        int duration = scanner.nextInt();

        System.out.println("Enter the intensity level (1 to 10): ");
        int intensityLevel = scanner.nextInt();

        // Create a new ProcessWorkout object with the entered details
        ProcessWorkout workout = new ProcessWorkout(exercises, duration, intensityLevel);

        // Call the printWorkout method to display the details
        workout.printWorkout();

        scanner.close(); // Closing the scanner
    }
}

